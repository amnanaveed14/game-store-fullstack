// CRUD operations for Game Store tables using Express & MSSQL
const express = require('express');
const mssql = require('mssql');
const app = express();
app.use(express.json());
const cors = require('cors');
app.use(cors());


const config = {
    user: 'sa',
    password: '12345678',
    server: 'localhost',
    database: 'GAMESTOREDB',
    port: 1433,
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};

async function connectToDatabase() {
    try {
        const pool = await mssql.connect(config);
        console.log('Connected to SQL Server');
        app.locals.db = pool;

        const PORT = 5000;
        app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
    } catch (err) {
        console.error('Database connection failed:', err);
        process.exit(1);
    }
}

connectToDatabase();

// Define a basic route
app.get('/', (req, res) => {
    res.send('Welcome to the RMS API!'); // response is coming from node api
});

// Define a test API route
app.get('/test', (req, res) => {
    res.json({ message: 'API is working!' });
});

// Add this route for frontend test
app.get('/api/message', (req, res) => {
    res.json({ message: 'Hello from backend!' });
});

// -------- USERS --------
app.get('/users', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Users');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get('/users/:id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const userId = req.params.id;

        const result = await pool
            .request()
            .input('userId', userId)
            .query('SELECT * FROM Users WHERE user_id = @userId');

        if (result.recordset.length === 0) {
            res.status(404).json({ message: 'User not found' });
        } else {
            res.json(result.recordset[0]); // Return the single user
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


app.post('/users', async (req, res) => {
    const { username, email, password, role } = req.body;

    if (!username || !email || !password || !role) {
        return res.status(400).json({ message: 'Missing fields' });
    }

    try {
        const pool = app.locals.db;

        // Check if the username already exists
        const usernameCheck = await pool.request()
            .input('username', mssql.VarChar, username)
            .query('SELECT COUNT(*) AS count FROM Users WHERE username = @username');

        if (usernameCheck.recordset[0].count > 0) {
            return res.status(400).json({ message: 'Username already taken' });
        }

        // Insert new user
        const result = await pool.request()
            .input('username', mssql.VarChar, username)
            .input('email', mssql.VarChar, email)
            .input('password', mssql.VarChar, password) // Optional: hash this before storing
            .input('role', mssql.VarChar, role)
            .query(`INSERT INTO Users (username, email, password, role)
                    OUTPUT INSERTED.user_id
                    VALUES (@username, @email, @password, @role)`);

        res.json({ message: 'User created', user_id: result.recordset[0].user_id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const pool = await mssql.connect(config);
        const result = await pool.request()
            .input('email', mssql.VarChar, email)
            .input('password', mssql.VarChar, password)
            .query('SELECT user_id, username FROM Users WHERE email = @email AND password = @password');

        if (result.recordset.length > 0) {
            const user = result.recordset[0];
            res.status(200).json({
                success: true,
                user: {
                    user_id: user.user_id,  // Ensure user_id is returned
                    username: user.username,
                }
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid email or password' });
        }
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});


app.put('/users/:id', async (req, res) => {
    const { username, email, password, role } = req.body;
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request()
            .input('id', mssql.Int, id)
            .input('username', mssql.VarChar, username)
            .input('email', mssql.VarChar, email)
            .input('password', mssql.VarChar, password)
            .input('role', mssql.VarChar, role)
            .query('UPDATE Users SET username=@username, email=@email, password=@password, role=@role WHERE user_id=@id');
        res.json({ message: 'User updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/users/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request().input('id', mssql.Int, id).query('DELETE FROM Users WHERE user_id=@id');
        res.json({ message: 'User deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// -------- GAMES --------

app.get('/games', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Games');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get('/games/:id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const gameId = req.params.id;

        const result = await pool
            .request()
            .input('gameId', gameId)
            .query('SELECT * FROM Games WHERE game_id = @gameId');

        if (result.recordset.length === 0) {
            res.status(404).json({ message: 'Game not found' });
        } else {
            res.json(result.recordset[0]); // Return single game object
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/games', async (req, res) => {
    const { title, description, price, genre, platform } = req.body;
    try {
        const pool = app.locals.db;
        const result = await pool.request()
            .input('title', mssql.VarChar, title)
            .input('description', mssql.Text, description)
            .input('price', mssql.Decimal, price)
            .input('genre', mssql.VarChar, genre)
            .input('platform', mssql.VarChar, platform)
            .query('INSERT INTO Games (title, description, price, genre, platform) OUTPUT INSERTED.game_id VALUES (@title, @description, @price, @genre, @platform)');
        res.json({ message: 'Game created', game_id: result.recordset[0].game_id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/games/:id', async (req, res) => {
    const { title, description, price, genre, platform } = req.body;
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request()
            .input('id', mssql.Int, id)
            .input('title', mssql.VarChar, title)
            .input('description', mssql.Text, description)
            .input('price', mssql.Decimal, price)
            .input('genre', mssql.VarChar, genre)
            .input('platform', mssql.VarChar, platform)
            .query('UPDATE Games SET title=@title, description=@description, price=@price, genre=@genre, platform=@platform WHERE game_id=@id');
        res.json({ message: 'Game updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/games/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request().input('id', mssql.Int, id).query('DELETE FROM Games WHERE game_id=@id');
        res.json({ message: 'Game deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// -------- INVENTORY --------
app.get('/inventory', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Inventory');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get('/inventory/:id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const inventoryId = req.params.id;

        const result = await pool
            .request()
            .input('inventoryId', inventoryId)
            .query('SELECT * FROM Inventory WHERE inventory_id = @inventoryId');

        if (result.recordset.length === 0) {
            res.status(404).json({ message: 'Inventory item not found' });
        } else {
            res.json(result.recordset[0]); // Return the specific item
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/inventory', async (req, res) => {
    const { game_id, stock_quantity } = req.body;
    try {
        const pool = app.locals.db;
        const result = await pool.request()
            .input('game_id', mssql.Int, game_id)
            .input('stock_quantity', mssql.Int, stock_quantity)
            .query('INSERT INTO Inventory (game_id, stock_quantity) OUTPUT INSERTED.game_id VALUES (@game_id, @stock_quantity)');
        res.json({ message: 'Inventory entry created', game_id: result.recordset[0].game_id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/inventory/:game_id', async (req, res) => {
    const { stock_quantity } = req.body;
    const { game_id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request()
            .input('game_id', mssql.Int, game_id)
            .input('stock_quantity', mssql.Int, stock_quantity)
            .query('UPDATE Inventory SET stock_quantity=@stock_quantity WHERE game_id=@game_id');
        res.json({ message: 'Inventory updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/inventory/:game_id', async (req, res) => {
    const { game_id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request().input('game_id', mssql.Int, game_id).query('DELETE FROM Inventory WHERE game_id=@game_id');
        res.json({ message: 'Inventory entry deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// -------- ORDERS --------
app.get('/orders', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Orders');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get('/orders/:id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const orderId = req.params.id;

        const result = await pool
            .request()
            .input('orderId', orderId)
            .query('SELECT * FROM Orders WHERE order_id = @orderId');

        if (result.recordset.length === 0) {
            res.status(404).json({ message: 'Order not found' });
        } else {
            res.json(result.recordset[0]); // Return specific order
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/orders', async (req, res) => {
    const { user_id, items } = req.body;
    const pool = app.locals.db;

    if (!user_id || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ message: 'User ID and non-empty items array are required' });
    }

    const transaction = new mssql.Transaction(pool);

    try {
        await transaction.begin();

        // Calculate total_amount
        const total_amount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        // Insert into Orders table
        const request = new mssql.Request(transaction);
        const orderResult = await request
            .input('user_id', mssql.Int, user_id)
            .input('total_amount', mssql.Decimal(10, 2), total_amount)
            .query(`
                INSERT INTO Orders (user_id, order_date, total_amount)
                OUTPUT INSERTED.order_id
                VALUES (@user_id, GETDATE(), @total_amount)
            `);

        const order_id = orderResult.recordset[0].order_id;
        const game_id = parseInt(req.body.game_id); // Make sure it's parsed to a number

        // Insert into Order_Items table
        for (const item of items) {
            await new mssql.Request(transaction)
                .input('order_id', mssql.Int, order_id)
                .input('game_id', mssql.Int, item.game_id)
                .input('quantity', mssql.Int, item.quantity)
                .input('price', mssql.Decimal(10, 2), item.price)
                .query(`
                    INSERT INTO Order_Items (order_id, game_id, quantity, price)
                    VALUES (@order_id, @game_id, @quantity, @price)
                `);
        }

        await transaction.commit();
        return res.status(201).json({ message: 'Order placed successfully', order_id });

    } catch (error) {
        await transaction.rollback();
        console.error('Error placing order:', error);
        return res.status(500).json({ message: 'Failed to place order', error: error.message });
    }
});


app.put('/orders/:id', async (req, res) => {
    const { user_id, total_amount, status } = req.body;
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request()
            .input('id', mssql.Int, id)
            .input('user_id', mssql.Int, user_id)
            .input('total_amount', mssql.Decimal, total_amount)
            .input('status', mssql.VarChar, status)
            .query('UPDATE Orders SET user_id=@user_id, total_amount=@total_amount, status=@status WHERE order_id=@id');
        res.json({ message: 'Order updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/orders/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request().input('id', mssql.Int, id).query('DELETE FROM Orders WHERE order_id=@id');
        res.json({ message: 'Order deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// -------- ORDER_ITEMS --------
app.get('/order-items', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Order_Items');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.post('/order-items', async (req, res) => {
    const { order_id, game_id, quantity, price } = req.body;
    const gameId = parseInt(game_id, 10);
  
    if (isNaN(gameId)) {
      return res.status(400).json({ error: 'Invalid game_id parameter' });
    }
  
    try {
      const pool = app.locals.db;
      const result = await pool.request()
        .input('order_id', mssql.Int, order_id)
        .input('game_id', mssql.Int, gameId)
        .input('quantity', mssql.Int, quantity)
        .input('price', mssql.Decimal, price)
        .query('INSERT INTO Order_Items (order_id, game_id, quantity, price) OUTPUT INSERTED.order_item_id VALUES (@order_id, @game_id, @quantity, @price)');
      res.json({ message: 'Order item created', order_item_id: result.recordset[0].order_item_id });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  


app.put('/order-items/:id', async (req, res) => {
    const { order_id, game_id, quantity, price } = req.body;
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request()
            .input('id', mssql.Int, id)
            .input('order_id', mssql.Int, order_id)
            .input('game_id', mssql.Int, game_id)
            .input('quantity', mssql.Int, quantity)
            .input('price', mssql.Decimal, price)
            .query('UPDATE Order_Items SET order_id=@order_id, game_id=@game_id, quantity=@quantity, price=@price WHERE order_item_id=@id');
        res.json({ message: 'Order item updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/order-items/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request().input('id', mssql.Int, id).query('DELETE FROM Order_Items WHERE order_item_id=@id');
        res.json({ message: 'Order item deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// Function to retrieve an order by ID from the database
const getOrderById = async (orderId) => {
    try {
        const pool = app.locals.db;
        const order = await pool.query('SELECT * FROM orders WHERE order_id = $1', [orderId]);
        if (!order) {
            throw new Error('Order not found');
        }
        const items = await mssql.query('SELECT * FROM order_items WHERE order_id = $1', [orderId]);
        return { ...order, items };
    } catch (err) {
        console.error('Error in getOrderById:', err);
        throw err;
    }
};


// ---- order->orderid->summary for proceed to checkout
// ---- there is not table for this
app.get('/orders/:id/summary', async (req, res) => {
    try {
        const orderId = req.params.id;
        console.log(`Fetching summary for order: ${orderId}`);
        const orderSummary = await getOrderById(orderId);
        console.log('Order Summary:', orderSummary);

        if (!orderSummary) {
            return res.status(404).json({ error: 'Order not found' });
        }

        res.status(200).json(orderSummary);
    } catch (err) {
        console.error('Error fetching order summary:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});





// -------- PAYMENTS --------
app.get('/payments', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Payments');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.get('/payments/:id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const paymentId = req.params.id; // Get the ID from the URL parameter
        const result = await pool.request()
            .input('paymentId', pool.Int, paymentId) // Sanitize and pass the paymentId to the query
            .query('SELECT * FROM Payments WHERE PaymentID = @paymentId'); // Adjust query to filter by ID
        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'Payment not found' });
        }
        res.json(result.recordset[0]); // Return the first record, as ID is unique
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/payments', async (req, res) => {
    try {
        const { order_id, payment_method, payment_status } = req.body;
        const result = await pool.request()
            .input('order_id', sql.Int, order_id)
            .input('payment_method', sql.VarChar, payment_method)
            .input('payment_status', sql.VarChar, payment_status)
            .query(`
                INSERT INTO Payments (order_id, payment_method, payment_status)
                VALUES (@order_id, @payment_method, @payment_status)
            `);
        res.status(201).json({ message: 'Payment recorded successfully' });
    } catch (err) {
        console.error('Payment insert error:', err);
        res.status(500).json({ message: 'Failed to record payment' });
    }
});

app.put('/payments/:id', async (req, res) => {
    const { order_id, payment_status, payment_method } = req.body;
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request()
            .input('id', mssql.Int, id)
            .input('order_id', mssql.Int, order_id)
            .input('payment_status', mssql.VarChar, payment_status)
            .input('payment_method', mssql.VarChar, payment_method)
            .query('UPDATE Payments SET order_id=@order_id, payment_status=@payment_status, payment_method=@payment_method WHERE payment_id=@id');
        res.json({ message: 'Payment updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/payments/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const pool = app.locals.db;
        await pool.request().input('id', mssql.Int, id).query('DELETE FROM Payments WHERE payment_id=@id');
        res.json({ message: 'Payment deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ✅ GET all inventory items
app.get('/inventory', async (req, res) => {
    try {
        const pool = app.locals.db;
        const result = await pool.request().query('SELECT * FROM Inventory');
        res.status(200).json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ✅ POST new inventory item
app.post('/inventory', async (req, res) => {
    try {
        const pool = app.locals.db;
        const { game_id, quantity, price } = req.body;

        const total_amount = quantity * price;

        await pool
            .request()
            .input('game_id', mssql.Int, game_id)
            .input('quantity', mssql.Int, quantity)
            .input('price', mssql.Float, price)
            .input('total_amount', mssql.Float, total_amount)
            .query(`
                INSERT INTO Inventory (game_id, quantity, price, total_amount)
                VALUES (@game_id, @quantity, @price, @total_amount)
            `);

        res.status(201).json({ message: 'Inventory item added successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ✅ PUT update inventory item
app.put('/inventory/:inventory_id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const { inventory_id } = req.params;
        const { game_id, quantity, price } = req.body;

        const total_amount = quantity * price;

        await pool
            .request()
            .input('inventory_id', mssql.Int, inventory_id)
            .input('game_id', mssql.Int, game_id)
            .input('quantity', mssql.Int, quantity)
            .input('price', mssql.Float, price)
            .input('total_amount', mssql.Float, total_amount)
            .query(`
                UPDATE Inventory
                SET game_id = @game_id,
                    quantity = @quantity,
                    price = @price,
                    total_amount = @total_amount
                WHERE inventory_id = @inventory_id
            `);

        res.status(200).json({ message: 'Inventory item updated successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ✅ DELETE inventory item
app.delete('/inventory/:inventory_id', async (req, res) => {
    try {
        const pool = app.locals.db;
        const { inventory_id } = req.params;

        await pool
            .request()
            .input('inventory_id', mssql.Int, inventory_id)
            .query(`
                DELETE FROM Inventory WHERE inventory_id = @inventory_id
            `);

        res.status(200).json({ message: 'Inventory item deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});