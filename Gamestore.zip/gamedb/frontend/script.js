// Initialize an empty cart
let cartItems = [];

// Function to handle adding an item to the cart
function addToCart(gameId, title, price) {
    const existingItem = cartItems.find(item => item.gameId === gameId);
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cartItems.push({
            gameId,
            title,
            price,
            quantity: 1
        });
    }

    // Save updated cart to localStorage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartDisplay(); // Update cart display after adding item
}

// Function to update the cart display (on the main page)
function updateCartDisplay() {
    const cartTableBody = document.getElementById('cart-items');
    cartTableBody.innerHTML = ''; // Clear previous cart items
    let totalPrice = 0;

    cartItems.forEach(item => {
        const row = document.createElement('tr');

        // Title
        const titleCell = document.createElement('td');
        titleCell.textContent = item.title;

        // Price
        const priceCell = document.createElement('td');
        priceCell.textContent = `$${item.price.toFixed(2)}`;

        // Quantity
        const quantityCell = document.createElement('td');
        quantityCell.textContent = item.quantity;

        // Subtotal
        const subtotalCell = document.createElement('td');
        subtotalCell.textContent = `$${(item.price * item.quantity).toFixed(2)}`;

        // Actions (Remove Button)
        const actionsCell = document.createElement('td');
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.onclick = () => removeItem(item.gameId);
        actionsCell.appendChild(removeBtn);

        // Append cells to the row
        row.appendChild(titleCell);
        row.appendChild(priceCell);
        row.appendChild(quantityCell);
        row.appendChild(subtotalCell);
        row.appendChild(actionsCell);

        // Append row to the cart table
        cartTableBody.appendChild(row);

        totalPrice += item.price * item.quantity;
    });

    // Update total price display
    document.getElementById('total-price').textContent = totalPrice.toFixed(2);
}

// Function to remove an item from the cart
function removeItem(gameId) {
    const itemIndex = cartItems.findIndex(item => item.gameId === gameId);
    if (itemIndex > -1) {
        cartItems.splice(itemIndex, 1);
        // Update the localStorage after removing the item
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartDisplay();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');

    // Event listeners for "Add to Cart" buttons
    addToCartButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const gameId = e.target.dataset.gameId;
            const title = e.target.dataset.title;
            const price = parseFloat(e.target.dataset.price); // Ensure price is a number
            
            addToCart(gameId, title, price);
        });
    });
});
