document.addEventListener('DOMContentLoaded', function () {
    const registerForm = document.getElementById('registerForm');
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('email-error');

    // Function to validate email format
    function validateEmail(email) {
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        return emailRegex.test(email);
    }

    // Handle form submission
    registerForm.addEventListener('submit', async function (e) {
        e.preventDefault(); // Prevent form from submitting normally
        
        const email = emailInput.value;
        
        // Clear any previous error message
        emailError.textContent = '';
        
        // Validate email format
        if (!validateEmail(email)) {
            emailError.textContent = 'Please enter a valid email address.';
            return; // Prevent form submission if email is invalid
        }

        // Get other form data
        const userData = {
            username: document.getElementById('username').value,
            email: email,
            password: document.getElementById('password').value,
            role: 'customer' // ✅ add this
        };

        console.log(userData); // Make sure the values are correct before sending

        // Send data to the backend
        try {
            const response = await fetch('http://localhost:5000/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData),
            });

            const result = await response.json();
            if (response.ok) {
                alert('User registered successfully!');
            } else {
                alert('Error: ' + result.message); // Display the error message from the server
            }
        } catch (error) {
            console.error('Error:', error);
        }
    });
});
