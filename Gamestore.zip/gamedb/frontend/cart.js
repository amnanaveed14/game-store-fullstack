let cartItems = [];

function loadCartFromLocalStorage() {
    const storedCart = localStorage.getItem('cartItems');
    if (storedCart) {
        cartItems = JSON.parse(storedCart);
    }
}

function saveCartToLocalStorage() {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
}

function addItemToCart(item) {
    const existingItem = cartItems.find(cartItem => cartItem.gameId === item.gameId);
    if (existingItem) {
        existingItem.quantity += item.quantity;
    } else {
        cartItems.push(item);
    }
    saveCartToLocalStorage();
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartTableBody = document.getElementById('cart-items');
    cartTableBody.innerHTML = '';
    let totalPrice = 0;

    if (cartItems.length === 0) {
        const emptyMessage = document.createElement('tr');
        const emptyMessageCell = document.createElement('td');
        emptyMessageCell.colSpan = 5;
        emptyMessageCell.textContent = "Your cart is empty.";
        emptyMessage.appendChild(emptyMessageCell);
        cartTableBody.appendChild(emptyMessage);
    } else {
        cartItems.forEach(item => {
            const row = document.createElement('tr');

            const titleCell = document.createElement('td');
            titleCell.textContent = item.title;

            const priceCell = document.createElement('td');
            priceCell.textContent = `$${item.price.toFixed(2)}`;

            const quantityCell = document.createElement('td');
            quantityCell.textContent = item.quantity;

            const subtotalCell = document.createElement('td');
            subtotalCell.textContent = `$${(item.price * item.quantity).toFixed(2)}`;

            const actionsCell = document.createElement('td');
            const removeBtn = document.createElement('button');
            removeBtn.textContent = 'Remove';
            removeBtn.onclick = () => removeItem(item.gameId);
            actionsCell.appendChild(removeBtn);

            row.appendChild(titleCell);
            row.appendChild(priceCell);
            row.appendChild(quantityCell);
            row.appendChild(subtotalCell);
            row.appendChild(actionsCell);

            cartTableBody.appendChild(row);

            totalPrice += item.price * item.quantity;
        });
    }

    document.getElementById('total-price').textContent = totalPrice.toFixed(2);
}

function updateItemQuantity(gameId, newQuantity) {
    const item = cartItems.find(item => item.gameId === gameId);
    if (item && newQuantity > 0) {
        item.quantity = newQuantity;
        saveCartToLocalStorage();
        updateCartDisplay();
    } else if (newQuantity <= 0) {
        removeItem(gameId);
    }
}

function removeItem(gameId) {
    const index = cartItems.findIndex(item => item.gameId === gameId);
    if (index > -1) {
        cartItems.splice(index, 1);
        saveCartToLocalStorage();
        updateCartDisplay();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadCartFromLocalStorage();
    updateCartDisplay();

    document.getElementById('place-order-btn').addEventListener('click', async () => {
        if (cartItems.length === 0) {
            alert('Your cart is empty. Please add items before placing an order.');
            return;
        }

        const userIdRaw = localStorage.getItem('user_id');
        console.log('user_id from localStorage:', userIdRaw);

        const userId = parseInt(userIdRaw, 10);
        console.log('Parsed userId:', userId);

        if (!userIdRaw || isNaN(userId)) {
            alert('You must be logged in to place an order.');
            window.location.href = 'login.html';
            return;
        }

        const order = {
            user_id: userId,
            items: cartItems.map(item => ({
                game_id: +item.gameId,  // convert string to number
                price: item.price,
                quantity: item.quantity
            }))
        };

        try {
            const response = await fetch('http://localhost:5000/orders', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(order),
            });

            const data = await response.json();
            console.log('Order response:', data);

           if (data.order_id) {
    localStorage.setItem('latestOrderId', data.order_id);

    const paymentMethod = document.getElementById('payment-method').value;

    await fetch('http://localhost:5000/payments', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            order_id: data.order_id,
            payment_method: paymentMethod,
            payment_status: 'paid' // or set based on your app's logic
        })
    });

    localStorage.removeItem('cartItems'); 
    alert('Order placed and payment recorded successfully!');
    window.location.href = 'order-confirmation.html'; // or wherever you redirect
} else {
    alert('Error creating the order. Please try again.');
}

        } catch (error) {
            console.error('Order placement failed:', error);
            alert('Failed to place the order.');
        }
    });
});
