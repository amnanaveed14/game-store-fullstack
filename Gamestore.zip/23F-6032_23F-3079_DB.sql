-- Create the database
CREATE DATABASE GAMESTOREDB;
GO

-- Use the database
USE GAMESTOREDB;
GO

-- Users Table
CREATE TABLE Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) CHECK (role IN ('admin', 'customer')) NOT NULL
);
GO

select * from Users

-- Games Table
CREATE TABLE Games (
    game_id INT IDENTITY(1,1) PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    genre VARCHAR(50),
    platform VARCHAR(50)
);
GO

-- Inventory Table
CREATE TABLE Inventory (
    game_id INT PRIMARY KEY,
    stock_quantity INT NOT NULL DEFAULT 0,
    FOREIGN KEY (game_id) REFERENCES Games(game_id) ON DELETE CASCADE
);
GO

-- Orders Table
CREATE TABLE Orders (
    order_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    order_date DATETIME DEFAULT GETDATE(),
    total_amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) CHECK (status IN ('pending', 'completed', 'cancelled')) DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);
GO

-- Order_Items Table
CREATE TABLE Order_Items (
    order_item_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    game_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (game_id) REFERENCES Games(game_id) ON DELETE CASCADE
);
GO

-- Payments Table
CREATE TABLE Payments (
    payment_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    payment_date DATETIME DEFAULT GETDATE(),
    payment_status VARCHAR(20) CHECK (payment_status IN ('pending', 'paid', 'failed')) DEFAULT 'pending',
    payment_method VARCHAR(50),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE
);
GO
ALTER TABLE Payments
ADD CONSTRAINT DF_Payments_PaymentMethod
DEFAULT 'Jazzcash' FOR payment_method;


-- Trigger to update inventory after inserting into Order_Items
CREATE TRIGGER trg_UpdateInventoryAfterOrder
ON Order_Items
AFTER INSERT
AS
BEGIN
    UPDATE Inventory
    SET stock_quantity = stock_quantity - i.quantity
    FROM Inventory inv
    INNER JOIN inserted i ON inv.game_id = i.game_id;
END;
GO

-- View: Order Summary
CREATE VIEW OrderSummary AS
SELECT 
    o.order_id,
    u.username,
    o.order_date,
    o.total_amount,
    p.payment_status,
    p.payment_method
FROM Orders o
JOIN Users u ON o.user_id = u.user_id
JOIN Payments p ON o.order_id = p.order_id;
GO

-- Indexes
CREATE INDEX idx_users_email ON Users(email);
CREATE INDEX idx_games_title ON Games(title);
CREATE INDEX idx_orders_userid ON Orders(user_id);
GO

INSERT INTO Users (username, email, password, role) VALUES
('admin1', 'admin1@example.com', 'adminpass', 'admin'),
('customer1', 'cust1@example.com', 'custpass1', 'customer'),
('customer2', 'cust2@example.com', 'custpass2', 'customer');

-- Inserting 20 additional games into the Games table
INSERT INTO Games (title, description, price, genre, platform) VALUES
('Tom Clancys Rainbow Six Siege', 'The best action-packed shooter experience awaits you.', 59.99, 'Shooter', 'PC, PS4, Xbox One'),
('Spiderman', 'Open-world action game where players control Spider-Man as he fights crime and explores New York City.', 49.99, 'Action', 'PS4, PS5'),
('Uncharted', 'Action-adventure game where players control Nathan Drake on treasure-hunting adventures across the globe.', 39.99, 'Action Adventure', 'PS4, PS5'),
('Dead By Daylight', 'Multiplayer survival horror game where players must escape from a killer or play as the killer.', 29.99, 'Horror', 'PC, PS4, Xbox One'),
('Forza Horizon 5', 'Open-world racing game set in a vast recreation of Mexico with a variety of races and vehicles.', 59.99, 'Racing', 'Xbox Series X, Xbox One'),
('Deceit 2', 'Multiplayer game where players must figure out who the traitor is while surviving against various dangers.', 19.99, 'Survival', 'PC'),
('Gran Turismo 7', 'Realistic racing simulation game with a wide variety of cars and tracks to compete on.', 69.99, 'Racing', 'PS4, PS5'),
('Marvel Rivals', 'Fighting game featuring Marvel superheroes, each with unique powers and abilities.', 39.99, 'Fighting', 'PS4, Xbox One'),
('Grand Theft Auto 5', 'Open-world action game where players engage in crime and exploration in a fictional city.', 29.99, 'Action', 'PC, PS4, Xbox One'),
('Valorant', 'Tactical shooter where players work together in teams to defeat the enemy team by planting bombs or defusing them.', 30.00, 'Shooter', 'PC'),
('Minecraft', 'Sandbox game where players build and explore a blocky, procedurally-generated world.', 19.99, 'Adventure', 'PC, PS4, Xbox One, Switch'),
('The Texas Chain Saw Massacre', 'Horror game where players must survive against the terrifying Leatherface and his family.', 29.99, 'Horror', 'PC, PS4, Xbox One'),
('Batman: Arkham Knight', 'Action-adventure game where players control Batman as he faces the Scarecrow and the Arkham Knight.', 19.99, 'Action', 'PS4, Xbox One, PC'),
('BATMAN: Arkham City', 'Open-world action game where players control Batman to stop the criminal chaos in Arkham City.', 14.99, 'Action', 'PS3, Xbox 360, PC'),
('Red Dead Redemption 2', 'Open-world action game set in the late 1800s, following the story of Arthur Morgan in the Van der Linde gang.', 49.99, 'Action', 'PS4, Xbox One'),
('Assassins Creed II', 'Action RPG where players control Ezio Auditore as he seeks revenge during the Renaissance in Italy.', 19.99, 'Action RPG', 'PS3, Xbox 360, PC'),
('The Legend of Zelda: Breath of the Wild', 'Open-world action-adventure game where players explore Hyrule to defeat Calamity Ganon.', 59.99, 'Action', 'Nintendo Switch'),
('Super Mario Odyssey', '3D platformer where Mario travels to different kingdoms to rescue Princess Peach and defeat Bowser.', 49.99, 'Platformer', 'Nintendo Switch'),
('Animal Crossing: New Horizons', 'Life simulation game where players design and build their own island, interact with villagers, and more.', 59.99, 'Simulation', 'Nintendo Switch'),
('Mario Kart 8 Deluxe', 'Kart racing game with fast-paced action, various characters, and fun multiplayer modes.', 49.99, 'Racing', 'Nintendo Switch'),
('Splatoon 2', 'Third-person shooter where players control squid-like characters in team-based ink battles.', 39.99, 'Shooter', 'Nintendo Switch');


-- Add default stock of 50 units for each game
INSERT INTO Inventory (game_id, stock_quantity)
SELECT game_id, 50 FROM Games;
GO

CREATE TABLE Game_Platforms (
    game_id INT,
    platform VARCHAR(50),
    FOREIGN KEY (game_id) REFERENCES Games(game_id) ON DELETE CASCADE
);
GO

--check krlo
INSERT INTO Game_Platforms (game_id, platform) VALUES
(1, 'PC'), (1, 'PS4'), (1, 'Xbox One'),
(2, 'PS4'), (2, 'PS5')
go

DROP TRIGGER IF EXISTS trg_UpdateInventoryAfterOrder;
GO
CREATE TRIGGER trg_UpdateInventoryAfterOrder
ON Order_Items
AFTER INSERT
AS
BEGIN
    -- Check for insufficient stock
    IF EXISTS (
        SELECT 1
        FROM Inventory inv
        JOIN inserted i ON inv.game_id = i.game_id
        WHERE inv.stock_quantity < i.quantity
    )
    BEGIN
        RAISERROR ('Not enough stock available.', 16, 1);
        ROLLBACK;
        RETURN;
    END

    -- Reduce stock
    UPDATE Inventory
    SET stock_quantity = stock_quantity - i.quantity
    FROM Inventory inv
    JOIN inserted i ON inv.game_id = i.game_id;
END;
GO

-- Create a new order
INSERT INTO Orders (user_id, total_amount, status) VALUES
(2, 59.99, 'completed');
GO

-- Add item to the order
INSERT INTO Order_Items (order_id, game_id, quantity, price) VALUES
(1, 1, 1, 59.99);
GO

-- Record the payment
INSERT INTO Payments (order_id, payment_status, payment_method) VALUES
(1, 'paid', 'Jazzcash');
GO

select * from Orders
SELECT * FROM Users


SELECT * FROM Order_Items;
